
-- config.lua

application =
{
    content =
    {
            width = 320,
            height = 480,
            scale = "zoomStretch",
			
			imageSuffix =
			{
				["@2x"] = 1.5,
				["@4x"] = 4,
			},
    },
}


